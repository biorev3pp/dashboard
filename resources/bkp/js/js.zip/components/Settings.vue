<template>
    <div>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="outreach-tab" data-toggle="tab" href="#outreach" role="tab" aria-controls="outreach" aria-selected="true">Outreach</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="activecampaign-tab" data-toggle="tab" href="#activecampaign" role="tab" aria-controls="activecampaign" aria-selected="false">Activecampaign</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="five9-tab" data-toggle="tab" href="#five9" role="tab" aria-controls="five9" aria-selected="false">Five9</a>
        </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="outreach" role="tabpanel" aria-labelledby="outreach-tab">...</div>
            <div class="tab-pane fade" id="activecampaign" role="tabpanel" aria-labelledby="activecampaign-tab">...</div>
            <div class="tab-pane fade" id="five9" role="tabpanel" aria-labelledby="five9-tab">...</div>
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>