<template>
    <div class="mapping-div syn-report">
  
    </div>
</template>
<script>

export default {
    data() {
        return {
            loader:false,
            loader_url: '/img/spinner.gif',
        }
    },
    filters: {
    },
    computed: {
        
    },
    methods: {
        
    },
    beforeMount() {
      
    },
    mounted() {
        
    }
}
</script>